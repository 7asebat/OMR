#!/bin/bash

for f in *
do
  if [[ -d $f ]]; then
    cd $f
    for q in *
    do 
      mv -- "$q" "$f-$q"
    done
    cd ..
    mv $f/* ./
  fi

done
